<?php
include("../connect.php");
if (isset($_POST['sub']) == "sub") {
  $news = htmlspecialchars($_POST['news']);
  $date = date("Y-m-d H:i:s");
  $campus = htmlspecialchars($_POST['campus']);
  $sql = "INSERT INTO news (news,campus,date) VALUES ('$news','$campus', '$date')";
  $stmt = mysqli_query($con, $sql);
  if ($stmt) {
    echo "<script>alert('News Added Successfully');</script>";
  } else {
    echo "<script>alert('Failed to Add News');</script>";
  }
}
if (isset($_POST['update'])) {
  $news = htmlspecialchars($_POST['news']);
  $campus = htmlspecialchars($_POST['campus']);
  $id = $_POST['id'];
  $sql = "UPDATE news SET news='$news',campus='$campus' WHERE sr='$id'";
  $stmt = mysqli_query($con, $sql);
  if ($stmt) {
    echo "<script>alert('News Updated Successfully');</script>";
  } else {
    echo "<script>alert('Failed to Update News');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <?php include("link.php"); ?>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
  <div class="app-wrapper">
    <?php include("header.php"); ?>
    <main class="app-main">
      <!--begin::App Content Header-->
      <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
          <!--begin::Row-->
          <div class="row">
            <div class="col-sm-6">
              <h3 class="mb-0">News</h3>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">News</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div class="app-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12 connectedSortable">
              <div class="card mb-4 ">
                <div class="card-header">
                  <h3 class="card-title mt-2">News</h3>
                  <div class="d-flex justify-content-end align-items-center">
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewsModal"> Add </a>
                  </div>

                </div>
                <div class="card-body">
                  <table class="table table-bordered table-striped table-hover">
                    <thead>
                      <th>Sr</th>
                      <th>Campus</th>
                      <th>News</th>
                      <th>Date</th>
                      <th>Action</th>
                    </thead>
                    <tbody>
                      <?php
                      $sql = "SELECT * FROM news ORDER BY date DESC";
                      $res = mysqli_query($con, $sql);
                      if (mysqli_num_rows($res) > 0) {
                        $i = 1;
                        while ($row = mysqli_fetch_assoc($res)) {
                          echo "<tr class='news-row' data-id='" . $row['sr'] . "' data-campus='" . $row['campus'] . "'  data-news='" . $row['news'] . "'>
                                            <td>" . $i . "</td>
                                            <td>" . $row['campus'] . "</td>
                                            <td>" . $row['news'] . "</td>
                                            <td>" . $row['date'] . "</td>
                                            <td><a href='#' class='btn btn-primary btn-edit'>
                                            <i class='bi bi-pencil'></i>
                                            </a> | <a href='delete-news.php?id=" . $row['sr'] . "'  onclick='return confirm(\"Are you sure you want to delete this news ?\");' class='btn btn-danger'><i class='bi bi-trash'></i></a></td>
                                          </tr>";
                          $i++;
                        }
                      } else {
                        echo "<tr><td colspan='4' align='center'>
                                 <div class='alert alert-danger' role='alert'>
                              No records found.
                            </div>
                                </td></tr>";
                      }
                      ?>

                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <?php include("footer.php"); ?>
  </div>

  <?php include("script.php") ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <script>
    $(document).ready(function() {
      $('.btn-edit').on('click', function() {
        var newsRow = $(this).closest('.news-row');
        var newsId = newsRow.data('id');
        var newsDetails = newsRow.data('news');
        var campus = newsRow.data('campus');

        $('#editNewsModal').modal('show');
        $('#editNewsModal #news').val(newsDetails);
        $('#id').val(newsId);
        $('#campus').val(campus);

      });
    });
  </script>
  <!-- Modal -->
  <div class="modal fade" id="addNewsModal" tabindex="-1" aria-labelledby="addNewsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="addNewsForm" method="post">
          <div class="modal-header">
            <h5 class="modal-title" id="addNewsModalLabel">Add News</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label for="news" class="form-label">Campus</label>
              <select name="campus" id="" class="form-control">
                <option value="">Select</option>
                <option value="Gida">Gida</option>
                <option value="Buxipur">Buxipur</option>
              </select>
            </div>
            <div class="mb-3">
              <label for="news" class="form-label">News Details</label>
              <textarea class="form-control" id="news" name="news" required></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="sub" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="modal fade" id="editNewsModal" tabindex="-1" aria-labelledby="addNewsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="addNewsForm" method="post">
          <div class="modal-header">
            <h5 class="modal-title" id="addNewsModalLabel">Edit News</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          
          <div class="modal-body">
            <input type="hidden" name="id" id="id">
             <div class="mb-3">
              <label for="news" class="form-label">Campus</label>
              <select class="form-control" name="campus" id="campus">
                <option value="">Select</option>
                <option value="Gida">Gida</option>
                <option value="Buxipur">Buxipur</option>
              </select>
            </div>
            <div class="mb-3">
              <label for="news" class="form-label">News Details</label>
              <textarea class="form-control" id="news" name="news" required></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="update" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>

</html>