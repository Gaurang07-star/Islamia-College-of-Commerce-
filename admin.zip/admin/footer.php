<footer class="app-footer">
        <!--begin::To the end-->
        <div class="float-end d-none d-sm-inline">Designed By <a href="https://www.limatsoftsolutions.co.in/" target="_blank">Li-Mat Soft Solutions</a></div>
        <!--end::To the end-->
        <!--begin::Copyright-->
        <strong>
          Copyright &copy; 2025-2026&nbsp;
          <a href="https://adminlte.io" class="text-decoration-none">Islamia College of Commece Gorakhpur</a>.
        </strong>
        All rights reserved.
        <!--end::Copyright-->
      </footer>