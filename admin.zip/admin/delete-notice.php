<?php
include("../connect.php");
$id = $_GET['id'];
$sql = "delete from notice where campus='Buxipur' and sr='$id'";
$res = mysqli_query($con, $sql);
if ($res) {
    header("location:notice.php");
}
?>