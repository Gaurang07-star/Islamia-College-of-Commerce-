<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alumni Request | Islamia College of Commerce, Gorakhpur</title>
  <?php include("link.php"); ?>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
  <div class="app-wrapper">
    <?php include("header.php"); ?>
    <main class="app-main">
      <!--begin::App Content Header-->
      <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
          <!--begin::Row-->
          <div class="row">
            <div class="col-sm-6">
              <h3 class="mb-0">Alumni</h3>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Alumni</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div class="app-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12 connectedSortable">
              <div class="card mb-4 ">
                <div class="card-header">
                  <h3 class="card-title mt-2">Alumni</h3>


                </div>
                <div class="card-body table-responsive">
                  <table class="table table-bordered table-striped table-hover">
                    <thead align="center">
                      <th>Sr</th>
                      <th>Campus</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Action</th>
                    </thead>
                    <tbody align="center">
                      <?php
                      include("../connect.php");
                      $sql = "select * from alumni  order by date desc";
                      $stmt = mysqli_query($con, $sql);
                      if (mysqli_num_rows($stmt) > 0) {
                        $i = 1;
                        while ($row = mysqli_fetch_assoc($stmt)) {
                          echo "<tr class='alumni-row' 
                                data-name='" . $row['name'] . "' 
                                data-email='" . $row['email'] . "' 
                                data-contact='" . $row['contact'] . "' 
                                data-course='" . $row['course'] . "' 
                                data-batch='" . $row['batch'] . "' 
                                data-picture='" . $row['picture'] . "'
                                data-campus='" . $row['campus'] . "'>
                                <td>" . $i . "</td>
                                <td>" . $row['campus'] . "</td>
                                <td>" . $row['name'] . "</td>
                                <td>" . $row['email'] . "</td>
                                <td>" . $row['contact'] . "</td>
                                <td>
                                  <button type='button' class='btn btn-primary btn-view'>
                                    <i class='bi bi-eye'></i>
                                  </button>
                                  <a href='alumni-delete.php?id=" . $row['sr'] . "' onclick='return confirm(\"Are you sure you want to delete this alumni request ?\");' class='btn btn-danger'>
                                    <i class='bi bi-trash'></i>
                                  </a>
                                 
                                </td>
                              </tr>";

                          $i++;
                        }
                      } else{
                        echo "<tr>
                          <td colspan='5'>
                            <div class='alert alert-danger' role='alert'>
                              No records found.
                            </div>
                          </td>
                        </tr>";
                      }
                      ?>

                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="alumniModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content p-3">
            <div class="modal-header">
              <h5 class="modal-title">Alumni Details</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <div class="col-7">
                  <p><strong>Name:</strong> <span id="modalName"></span></p>
                  <p><strong>Email:</strong> <span id="modalEmail"></span></p>
                  <p><strong>Contact:</strong> <span id="modalContact"></span></p>
                  <p><strong>Campus:</strong> <span id="modalCampus"></span></p>
                  <p><strong>Course:</strong> <span id="modalCourse"></span></p>
                  <p><strong>Batch:</strong> <span id="modalBatch"></span></p>
                </div>
                <div class="col-5">
                  <img id="modalPhoto"
                    alt="Alumni Photo"
                    class="img-thumbnail" style="width: 250px; height: 250px; object-fit: cover;">

                </div>
              </div>

            </div>

          </div>
        </div>
      </div>
  </div>

  </main>
  <?php include("footer.php"); ?>
  </div>
  <?php include("script.php"); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script>
    $(document).ready(function() {
      $('.btn-view').on('click', function() {
        const row = $(this).closest('tr');

        $('#modalName').text(row.data('name'));
        $('#modalEmail').text(row.data('email'));
        $('#modalContact').text(row.data('contact'));
        $('#modalCourse').text(row.data('course') || 'N/A');
        $('#modalBatch').text(row.data('batch') || 'N/A');
        $('#modalCampus').text(row.data('campus') || 'N/A');

        const picture = '../' + row.data('picture');
        $('#modalPhoto').attr('src', picture);

        const modal = new bootstrap.Modal(document.getElementById('alumniModal'));
        modal.show();
      });
    });
  </script>

</body>

</html>