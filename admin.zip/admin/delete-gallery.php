<?php
    include("../connect.php");
    $id=$_GET['id'];
    $sql="delete from gallery where sr='$id'";
    $res=mysqli_query($con,$sql);
    if($res)
    {
        header("location:gallery.php");
    }
?>