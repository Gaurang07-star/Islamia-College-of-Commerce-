<?php
include("../connect.php");
$id = $_GET['id'];
$sql = "delete from news where sr='$id'";
$res = mysqli_query($con, $sql);
if ($res) {
    header("location:news.php");
}
?>