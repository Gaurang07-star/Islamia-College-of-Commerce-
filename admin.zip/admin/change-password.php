<?php
include("../connect.php");

if (isset($_POST['sub'])) {
    $user_id=$_POST['uid'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    $query = "SELECT * FROM login WHERE user_id='$user_id'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        if ($current_password == $row['password']) {
            if ($new_password == $confirm_password) {
                if (strlen($new_password) < 8) {
                    $msg='Password must be at least 8 characters long';
                } elseif (!preg_match('/[A-Z]/', $new_password)) {
                    $msg='Password must contain at least one uppercase letter';
                } elseif (!preg_match('/[a-z]/', $new_password)) {
                    $msg='Password must contain at least one lowercase letter';
                } elseif (!preg_match('/[0-9]/', $new_password)) {
                    $msg='Password must contain at least one number';
                } elseif (!preg_match('/[@$!%*?&]/', $new_password)) {
                    $msg='Password must contain at least one special character';
                } 
                else{
                $update_query = "UPDATE login SET password='$new_password' WHERE user_id='$user_id'";
                if (mysqli_query($con, $update_query)) {
                    echo "<script>alert('Password changed successfully');</script>";
                } else {
                    echo "<script>alert('Error updating password');</script>";
                }
            }
            } else {
                $msg1='New password and confirm password do not match';
            }
        } else {
            echo "<script>alert('Current password is incorrect');</script>";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password | ICC - Gida Campus</title>
    <?php include("link.php") ?>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
  <div class="app-wrapper">
    <?php include("header.php"); ?>
    <main class="app-main">
      <!--begin::App Content Header-->
      <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
          <!--begin::Row-->
          <div class="row">
            <div class="col-sm-6">
              <h3 class="mb-0">Change Password</h3>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Change Password</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div class="app-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Change Password</h5>
                        </div>
                        <div class="card-body">
                            <form method="post" class="form">
                                <div class="form-group mb-3">
                                    <label for="">Current Password</label>
                                    <input type="password" name="current_password" class="form-control" required placeholder="Enter Current Password">
                                </div>
                                <div class="form-group mb-3">
                                    <label for="">New Password</label>
                                    <input type="password" name="new_password" class="form-control" required placeholder="Enter New Password">
                                    <p class="text-danger"><?php if(isset($msg))echo $msg ?></p>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="">Confirm Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required placeholder="Confirm New Password">
                                    <p class="text-danger"><?php if(isset($msg1))echo $msg1 ?></p>
                                </div>
                                
                                <div class="form-group mb-3">
                                    <input type="hidden" name="uid" value="<?php if(isset($user_id)) echo $user_id ?>" id="">
                                    <button type="submit"  name="sub" class="btn btn-primary">Change Password</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </main>
    <?php include("footer.php"); ?>
  </div>
  <?php include("script.php") ?>
</body>
</html>
    
</body>
</html>