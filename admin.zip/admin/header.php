<?php
session_start();
if (!isset($_SESSION['uid'])) {
  header("location:../index.php");
}
$user_id = $_SESSION['uid'];
?>

<nav class="app-header navbar navbar-expand bg-body">
  <!--begin::Container-->
  <div class="container-fluid">
    <!--begin::Start Navbar Links-->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
          <i class="bi bi-list"></i>
        </a>
      </li>
    </ul>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item dropdown user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
          <span class="d-none d-md-inline">College Admin </span>
        </a>
        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">

          <li class="user-footer">
            <a href="logout.php" class="btn btn-default btn-flat float-end">Logout</a>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</nav>
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
  <!--begin::Sidebar Brand-->
  <div class="sidebar-brand justify-content-start">
    <!--begin::Brand Link-->
    <a href="dashboard.php" class="brand-link mx-3">
      <!--begin::Brand Image-->
      <img
        src="assets/img/logo.jpg"
        alt="ICC"
        class="brand-image opacity-100 shadow" />
      <!--end::Brand Image-->
      <!--begin::Brand Text-->
      <span class="brand-text fw-light">ICC</span>
      <!--end::Brand Text-->
    </a>
    <!--end::Brand Link-->
  </div>
  <!--end::Sidebar Brand-->
  <!--begin::Sidebar Wrapper-->
  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <!--begin::Sidebar Menu-->
      <ul
        class="nav sidebar-menu flex-column"
        data-lte-toggle="treeview"
        role="menu"
        data-accordion="false">
        <li class="nav-item menu-open">
          <a href="dashboard.php" class="nav-link active">
            <i class="nav-icon bi bi-speedometer"></i>
            <p>
              Dashboard
            </p>
          </a>

        </li>
        <li class="nav-item">
          <a href="news.php" class="nav-link">
            <i class="nav-icon bi bi-box-seam-fill"></i>
            <p>
              News
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="notice.php" class="nav-link">
            <i class="nav-icon bi bi-clipboard-fill"></i>
            <p>
              Notice
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="alumni.php" class="nav-link">
            <i class="nav-icon bi bi-person-bounding-box"></i>
            <p>
              Alumni Request
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="enquiry.php" class="nav-link">
            <i class="nav-icon bi bi-boxes"></i>
            <p>
              Enquiry
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="events.php" class="nav-link">
            <i class="nav-icon bi bi-palette"></i>
            <p>
              Events
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="gallery.php" class="nav-link">

            <i class="nav-icon bi bi-images"></i>
            <p>Gallery</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="change-password.php" class="nav-link">
            <i class="nav-icon bi bi-lock"></i>
            <p>Change Password</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="logout.php" class="nav-link">
            <i class="nav-icon bi-box-arrow-right"></i>
            <p>Logout</p>
          </a>
        </li>

      </ul>
      <!--end::Sidebar Menu-->
    </nav>
  </div>
  <!--end::Sidebar Wrapper-->
</aside>